#Script for cp folder database from other server to Our local

1. you have to give permission to the key for execute
   sudo chmod 777 linux-class.pem
   sudo chmod 777 scp_unzip.sh or sudo chmod u+x scp_unzip.sh
2. To run the script make you just type
      (./scp_frombackdump.sh "04_03_2016" )   "04_03_2016" == ("month_date_year") is an parameter give when we run the script  
 
  So the script will copy the database folder from one server to Our current directory and unzip automaticly
